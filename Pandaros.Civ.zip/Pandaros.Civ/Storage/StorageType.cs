﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pandaros.Civ.Storage
{
    public enum StorageType
    {
        Stockpile = 0,
        Crate
    }
}
