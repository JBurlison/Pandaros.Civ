﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pandaros.Civ
{
    public static class CommonSounds
    {
        public static string WoodCut = "woodCut";
        public static string WoodDeleteHeavy = "woodDeleteHeavy";
        public static string WoodPlace = "woodPlace";
        public static string WoodDeleteLight = "woodDeleteLight";
        public static string StoneDelete = "stoneDelete";
        public static string StonePlace = "stonePlace";
        public static string GrassDelete = "grassDelete";
        public static string DirtPlace = "dirtPlace";
    }
}
