﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pandaros.Civ
{
    public enum TextureType
    {
        aldebo,
        emissive,
        height,
        normal,
        npc,
        icon,
        image,
        none
    }
}
